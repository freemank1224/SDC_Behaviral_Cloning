# -*- coding: utf-8 -*-
"""
Created on Tue Mar  7 17:53:23 2017

@author: dyson
"""
import csv
import cv2
from PIL import Image
import matplotlib.pyplot as plt
import numpy as np
from keras.models import Sequential
from keras.layers import Dense, Activation, Flatten, Lambda, Cropping2D
from keras.layers.convolutional import Convolution2D
from keras.layers.pooling import MaxPooling2D


#lines = []
img_center_array = []
img_left_array = []
img_right_array = []
car_images = []

steering_center_array = []
steering_left_array = []
steering_right_array = []
steering_angles = []

with open('../recData/driving_log.csv') as csvfile:
    reader = csv.reader(csvfile)
    for element in reader:
        # Obtain steering angle
        steering_center = float(element[3])
        steering_center_array.append(steering_center)
        # Create adjusted steering measurements for the side camera images
        correction = 0.05
        steering_left = steering_center + correction
        steering_left_array.append(steering_left)
        steering_right = steering_center - correction
        steering_right_array.append(steering_right)
        
        # Read in images from center, left and right
        path = '../recData/IMG/'
        img_center = np.asarray(Image.open(path + element[0].split("\\")[-1]))
        img_center_array.append(img_center)
        img_left = np.asarray(Image.open(path + element[1].split("\\")[-1]))
        img_left_array.append(img_left)
        img_right = np.asarray(Image.open(path + element[2].split("\\")[-1]))
        img_right_array.append(img_right)
        
        
    # Enrich the data set
    car_images.extend(img_center_array)
    car_images.extend(img_left_array)
    car_images.extend(img_right_array)
    steering_angles.extend(steering_center_array)
    steering_angles.extend(steering_left_array)
    steering_angles.extend(steering_right_array)
#        lines.append(line)

augmented_images, augmented_measurements = [], []
for image, measurement in zip(car_images, steering_angles):
    augmented_images.append(image)
    augmented_measurements.append(measurement)
    augmented_images.append(cv2.flip(image, 1))
    augmented_measurements.append(measurement * -1.0)
#    car_images.append(cv2.flip(image, 1))
#    steering_angles.append(measurement * -1.0)
    
#plt.imshow(images[5])
y_train = np.array(augmented_measurements)
x_train = np.array(augmented_images)

model = Sequential()
#model.add(Flatten(input_shape=(160, 320, 3)))
model.add(Cropping2D(cropping=((50,20),(0,0)), input_shape=(160, 320, 3)))
model.add(Lambda(lambda x: x/255.0 - 0.5))
model.add(Convolution2D(10,5,5, activation='relu'))
model.add(MaxPooling2D())
model.add(Convolution2D(20,5,5, activation='relu'))
model.add(MaxPooling2D())
model.add(Convolution2D(40,5,5, activation='relu'))
model.add(MaxPooling2D())
model.add(Convolution2D(60,3,3, activation='relu'))
model.add(MaxPooling2D())
model.add(Convolution2D(80,2,2, activation='relu'))
model.add(Flatten())

model.add(Dense(500))
model.add(Dense(300))
model.add(Dense(100))
model.add(Dense(50))
model.add(Dense(1))

model.compile(loss='mse', optimizer='adam')
model.fit(x_train, y_train, validation_split=0.2, shuffle=True, nb_epoch=10)

model.save('model.h5')